 <?php 
          
            if(empty($_POST('username'))){
                
                echo "vacio";
            }else {
                
                echo("lleno");
                
            }
    
   ?>