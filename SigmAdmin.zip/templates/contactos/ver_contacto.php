    <div style="margin-top:-5px" id="page-wrapper" class="gray-bg1 gray-bg">
               <?php
                echo $this->element('vista_contactos');
              ?>
</div>
